function Error404() {
  return <h1>404 - Page Not Found</h1>;
}

export default Error404;
